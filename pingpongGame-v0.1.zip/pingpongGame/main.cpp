﻿#include"stdio.h"
#include"stdlib.h"
#include"windows.h"
#include"bios.h"

#include"conio.h"		//键盘控制
#include"time.h"


#include"graphics.h"


#include"方块信息结构体.h"
#include"界面.h"		//图形界面

#include"保存.h"
#include"读取.h"


#include"游戏.h"
#include"菜单.h"




int main()
{

	menu();

	return 0;
	system("pause");
}