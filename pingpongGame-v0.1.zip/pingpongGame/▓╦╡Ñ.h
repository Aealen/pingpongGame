int menu()
{
	initgr();
	settextstyle(23, 15, _T("����"));
	settextcolor(RED);
	outtextxy(200, 120, "Pingpong Game!!");
	settextcolor(YELLOW);
	outtextxy(250, 160, "---FangMingxuan ");
	settextcolor(WHITE);
	outtextxy(200, 200, "1.Start Game");
	outtextxy(200, 240, "2.Exit  Game ");
	outtextxy(200, 280, "3.Rank  ");
	
	int sel;
	printf("Please enter your selection:	");
	scanf_s("%d", &sel);


	while (sel < 1 || sel>3)
	{
		initgr();
		settextstyle(23, 15, _T("����"));
		settextcolor(RED);
		outtextxy(30, 120, "ERROR: Please enter correct selection!!!");
		settextcolor(YELLOW);
		outtextxy(30, 160, "You should enter your selection again!!!");
		outtextxy(30, 200, "Please enter your selection:	");
		settextcolor(WHITE);
		outtextxy(200, 240, "1.Start Game");
		outtextxy(200, 280, "2.Exit  Game ");
		outtextxy(200, 320, "3.Rank  ");
			scanf_s("%d\n", &sel);
	}

	switch(sel)
	{
	case 1:initgr(); picture(); move(); menu(); break;
	case 2:closegr(); break;
	case 3:menu(); break;
	}




	return 0;
	system("pause");
}