﻿#include"stdio.h"
#include"stdlib.h"
#include"windows.h"
#include"string.h"
#include"bios.h"
#include"conio.h"		//键盘控制
#include"time.h"


#include"graphics.h"


#include"全局变量.h"
#include"界面.h"		//图形界面


#include"读取.h"




#include"游戏.h"       //游戏主体
#include"排名.h"

#include"菜单.h"

#pragma comment(lib,"Winmm.Lib")


int main()
{
	

	menu();

	return 0;
	system("pause");
}